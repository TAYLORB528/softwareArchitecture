var searchData=
[
  ['featurecollection_0',['FeatureCollection',['../class_automation_a_p_i_1_1_feature_collection.html',1,'AutomationAPI']]],
  ['features_1',['Features',['../class_automation_a_p_i_1_1_part.html#a9f8f1e227e4b1387dae8f93effb06800',1,'AutomationAPI::Part']]]
];
