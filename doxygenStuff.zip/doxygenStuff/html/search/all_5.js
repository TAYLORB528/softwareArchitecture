var searchData=
[
  ['makepart_0',['MakePart',['../class_automation_a_p_i_1_1_session.html#a9bc4f856449824a3a367b4efdab07838',1,'AutomationAPI::Session']]],
  ['makewidgetfeature_1',['MakeWidgetFeature',['../class_automation_a_p_i_1_1_part.html#ae2ab1e4d7a2054cc6b2d0dfc1f3f5773',1,'AutomationAPI::Part']]]
];
