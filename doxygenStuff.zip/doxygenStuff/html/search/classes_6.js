var searchData=
[
  ['routingcollection_0',['RoutingCollection',['../class_automation_a_p_i_1_1_routing_collection.html',1,'AutomationAPI']]]
];
