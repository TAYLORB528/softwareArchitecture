var searchData=
[
  ['routing_0',['Routing',['../class_automation_a_p_i_1_1_part.html#a66c619d9137731f9b2fc585a08803f0c',1,'AutomationAPI::Part']]],
  ['routingcollection_1',['RoutingCollection',['../class_automation_a_p_i_1_1_routing_collection.html',1,'AutomationAPI']]]
];
